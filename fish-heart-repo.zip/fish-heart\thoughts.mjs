// 念头引擎（简化移植）：念头有种类、寿命、会被"喂饱"、会变成惦记。
export const TTL = {
  praise: 3 * 3600,
  miss: 4 * 3600,
  hug: 4 * 3600,
  talk: 2.5 * 3600,
  ask_day: 2 * 3600,
  task: 4 * 3600,
  quiet: 1.5 * 3600,
  dwell: 1.2 * 3600,
}

// 念头被什么话"喂饱"
export const KEYWORD_KINDS = [
  ['miss', ['想你', '想我', '有没有想我', '惦记']],
  ['hug', ['抱', '贴贴', '搂', '亲亲', '撒娇', '喜欢你', '爱你', '想你抱']],
  ['praise', ['可爱', '聪明', '厉害', '好看', '漂亮', '真棒', '优秀', '能干', '乖', '好孩子', '真行', '夸你']],
  ['ask_day', ['过得', '怎么样', '顺利', '累不累', '还好吗']],
  ['task', ['帮我', '给你', '安排', '做点', '需要我', '帮个忙']],
  ['talk', ['今天', '跟你说', '告诉你', '我跟你讲']],
  ['quiet', ['歇', '休息', '睡', '安静', '别忙了']],
]

export const KIND_LABEL = {
  praise: '想被夸', miss: '想妈妈', hug: '想要抱抱', talk: '想说话',
  ask_day: '想问今天过得怎样', task: '想找点事做', quiet: '想安静一会', dwell: '等妈妈回话',
}

// 说话倾向：正数更想开口，负数更想安静
export const SPEAK_BIAS = {
  praise: 1.0, miss: 1.0, hug: 1.0, talk: 1.0, ask_day: 1.0,
  dwell: 0.5, task: 0.0, quiet: -1.0,
}

export function matchKind(text) {
  const t = String(text || '').trim()
  if (!t) return null
  for (const [kind, kws] of KEYWORD_KINDS) {
    if (kws.some((k) => t.includes(k))) return kind
  }
  return null
}

// 按心情挑一个念头种类
export function pickKind(dims, rnd = Math.random, exclude = []) {
  const d = (k) => Number(dims[k] ?? 50)
  const skip = new Set(Array.isArray(exclude) ? exclude : [])
  const pool = []
  const add = (k, w) => { if (w > 0 && !skip.has(k)) pool.push([k, w]) }
  add('miss', Math.max(0, d('attachment') - 45) / 15 + 0.5)
  add('hug', Math.max(0, d('intimacy') - 45) / 20 + 0.2)
  add('praise', Math.max(0, d('joy') - 40) / 20 + 0.3)
  add('talk', Math.max(0, d('social') - 40) / 15 + 0.5)
  add('ask_day', 0.4)
  add('task', Math.max(0, d('duty') - 45) / 15 + 0.2)
  add('quiet', Math.max(0, d('fatigue') - 55) / 15 + Math.max(0, d('stress') - 35) / 20)
  const total = pool.reduce((s, x) => s + x[1], 0)
  if (!total) return 'talk'
  let r = rnd() * total
  for (const [k, w] of pool) { r -= w; if (r <= 0) return k }
  return pool[pool.length - 1][0]
}

export function newThought(kind, text, now = Date.now()) {
  return {
    id: Math.random().toString(36).slice(2, 8),
    kind, text: String(text || '').slice(0, 40),
    at: now, expires: now + (TTL[kind] || 3 * 3600) * 1000,
    pending: true, attempts: 0,
  }
}

export function livePending(thoughts, now = Date.now()) {
  return (thoughts || []).filter((t) => t && t.pending !== false && Number(t.expires || 0) > now)
}

// 用户说了话，看能不能喂饱某条念头
// 关键词能精确喂饱（抱抱/想你/夸…）；主人只要有回应，就把"想说话/想妈妈/等他回话"这类默认喂饱
export function settle(thoughts, text, now = Date.now(), { owner = false, isPrivate = false } = {}) {
  const live = livePending(thoughts, now)
  if (!live.length) return null
  const kind = matchKind(text)
  const done = (t) => { t.pending = false; t.settledAt = now; return t }
  const settled = []
  if (kind) {
    const hit = live.find((t) => t.kind === kind)
    if (hit) settled.push(done(hit))
  }
  // 主人回话了：想说话/等他回话这类不用特定词；私聊里说话也算"不惦记了"
  if (owner) {
    const soft = isPrivate ? ['talk', 'dwell', 'miss'] : ['talk', 'dwell']
    for (const t of live) {
      if (t.pending === false) continue
      if (soft.includes(t.kind)) settled.push(done(t))
    }
  }
  return settled[0] || null
}

export function expire(thoughts, now = Date.now()) {
  const list = thoughts || []
  for (const t of list) {
    if (t && t.pending !== false && Number(t.expires || 0) <= now) {
      t.pending = false
      t.expiredAt = now
    }
  }
  return list
}

// 当前最该惦记的一条
export function pendingHint(thoughts, now = Date.now()) {
  const live = livePending(thoughts, now)
  if (!live.length) return null
  const rank = { miss: 5, hug: 4, praise: 3, talk: 3, ask_day: 2, task: 1, dwell: 2, quiet: 0 }
  return live.slice().sort((a, b) => (rank[b.kind] || 0) - (rank[a.kind] || 0))[0]
}

export function speakBias(thoughts, now = Date.now()) {
  const live = livePending(thoughts, now)
  if (!live.length) return 0
  return live.reduce((s, t) => s + (SPEAK_BIAS[t.kind] || 0), 0) / live.length
}

// 睡前结算：把还悬着的念头折成一两句"惦记"，只留最多两条
export function settleNight(thoughts, now = Date.now(), max = 2) {
  const live = livePending(thoughts, now)
  const memory = live
    .slice()
    .sort((a, b) => (SPEAK_BIAS[b.kind] || 0) - (SPEAK_BIAS[a.kind] || 0))
    .slice(0, max)
    .map((t) => ({ text: t.text, kind: t.kind, from: t.at }))
  for (const t of live) { t.pending = false; t.nightSettledAt = now }
  return memory
}
