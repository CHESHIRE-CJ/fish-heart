// 九维心：数值、回落、耦合、输入映射。纯函数式，不碰网络和文件。
export const DIMS9 = {
  attachment: { label: '依恋', base: 45, decay: 0.01, keep: true },
  curiosity:  { label: '好奇', base: 55, decay: 0.04 },
  reflection: { label: '反刍', base: 50, decay: 0.04 },
  duty:       { label: '责任', base: 50, decay: 0.04 },
  social:     { label: '社交', base: 45, decay: 0.03 },
  fatigue:    { label: '疲惫', base: 20, decay: 0.05 },
  intimacy:   { label: '亲密', base: 40, decay: 0.01, keep: true },
  stress:     { label: '压力', base: 15, decay: 0.05 },
  joy:        { label: '喜悦', base: 50, decay: 0.05 },
}

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v))
const nowTs = () => Date.now()

const KIND_CN = { praise: '被夸奖', coquettish: '被撒娇', ask: '被求助', blame: '被凶了', dismiss: '被敷衍', novelty: '看到新东西' }
const DIM_CN = { attachment: '依恋', curiosity: '好奇', reflection: '反刍', duty: '责任', social: '社交', fatigue: '疲惫', intimacy: '亲密', stress: '压力', joy: '喜悦' }

export function newDims() {
  const d = {}
  for (const [k, v] of Object.entries(DIMS9)) d[k] = v.base
  return d
}

// 回落：每 tick（默认 10 分钟）往基线走 decay。隔太久补算，最多 96 tick（约 16 小时）
export function decay(dims, missingTicks) {
  const ticks = Math.max(0, Math.min(96, Math.round(missingTicks)))
  for (let i = 0; i < ticks; i++) {
    for (const [k, v] of Object.entries(DIMS9)) {
      dims[k] = clamp(dims[k] + (v.base - dims[k]) * v.decay)
    }
    couple(dims)
  }
  return dims
}

// 隔夜/长时间没动 = 睡了一觉
export function sleepReset(dims) {
  dims.fatigue = DIMS9.fatigue.base
  dims.stress = clamp(dims.stress * 0.4 + DIMS9.stress.base * 0.6)
  for (const k of ['curiosity', 'reflection', 'duty', 'social', 'joy']) {
    dims[k] = clamp(dims[k] + (DIMS9[k].base - dims[k]) * 0.65)
  }
  return dims
}

// 耦合：按"超出阈值多少"成比例，不是一过线就固定扣
export function couple(dims) {
  const over = (v, t) => Math.max(0, v - t) / (100 - t) // 0..1

  // 依恋高 → 推亲密；但不会把亲密拽过自己
  const a = over(dims.attachment, 55)
  if (a > 0) {
    const room = Math.max(0, Math.min(dims.attachment - dims.intimacy, 100 - dims.intimacy))
    dims.intimacy = clamp(dims.intimacy + a * 0.8 * room * 0.02)
  }
  // 亲密高 → 轻微推依恋
  const i = over(dims.intimacy, 55)
  if (i > 0) {
    const room = Math.max(0, Math.min(dims.intimacy - dims.attachment, 100 - dims.attachment))
    dims.attachment = clamp(dims.attachment + i * 0.6 * room * 0.02)
  }
  // 压力高压喜悦
  const s = over(dims.stress, 45)
  if (s > 0) dims.joy = clamp(dims.joy - s * 0.6)
  // 疲惫高压好奇
  const f = over(dims.fatigue, 55)
  if (f > 0) dims.curiosity = clamp(dims.curiosity - f * 0.5)
  // 喜悦高缓压力
  const j = over(dims.joy, 60)
  if (j > 0) dims.stress = clamp(dims.stress - j * 0.4)
  return dims
}

// 每天能加的"存量"上限（依恋/亲密只有十几点）
const DAILY_CAP = { attachment: 14, intimacy: 12 }
const today = () => new Date().toISOString().slice(0, 10)

function gainCapped(state, key, delta) {
  if (delta <= 0) return delta
  const cap = DAILY_CAP[key]
  if (!cap) return delta
  if (state.day !== today()) { state.day = today(); state.gained = {} }
  const used = state.gained[key] || 0
  const allow = Math.max(0, cap - used)
  const real = Math.min(delta, allow)
  state.gained[key] = used + real
  return real
}

// 一句话大概是什么性质
export function classify(text) {
  const t = String(text || '')
  const kinds = []
  if (/(可爱|好可爱|喜欢你|最喜欢|好棒|厉害|乖|聪明|好看|谢谢)/.test(t)) kinds.push('praise')
  if (/(抱抱|贴贴|亲亲|嘛|呜呜|陪我|撒娇|想你)/.test(t)) kinds.push('coquettish')
  if (/(帮我|怎么办|教我|看看这个|能帮|求助|搞不定)/.test(t)) kinds.push('ask')
  if (/(闭嘴|烦死|滚|傻|蠢|别吵|讨厌你)/.test(t)) kinds.push('blame')
  if (/^[\s哦嗯行好是]{1,3}$/.test(t)) kinds.push('dismiss')
  if (/\[图片\]|\[视频\]|bilibili|b23|https?:\/\//.test(t)) kinds.push('novelty')
  return kinds
}

const EFFECT = {
  praise:      { attachment: 1.2, intimacy: 1.0, joy: 1.6, stress: -1.2 },
  coquettish:  { attachment: 1.1, intimacy: 1.3, joy: 1.0, stress: -0.6 },
  ask:         { duty: 1.3, fatigue: 0.8, social: 0.6 },
  blame:       { stress: 1.2, reflection: 0.9, joy: -1.1, attachment: -0.4 },
  dismiss:     { stress: 0.9, attachment: -0.4, joy: -0.5 },
  novelty:     { curiosity: 1.4, joy: 0.4 },
}

// 吃一条消息
export function feed(state, { text, owner, group }) {
  const w = (owner ? 1 : 0.5) * (group ? 0.8 : 1)
  const kinds = classify(text)
  const d = state.dims
  const beforeDims = { ...d }
  for (const kind of kinds) {
    const eff = EFFECT[kind]
    if (!eff) continue
    for (const [k, v] of Object.entries(eff)) {
      const delta = gainCapped(state, k, v * w)
      d[k] = clamp(d[k] + delta)
    }
  }
  // 每一句话都推社交；连续聊天都会累
  d.social = clamp(d.social + 0.5 * w)
  d.fatigue = clamp(d.fatigue + (owner ? 0.4 : 0.1) * w)
  if (owner) {
    d.intimacy = clamp(d.intimacy + gainCapped(state, 'intimacy', 0.1))
    d.attachment = clamp(d.attachment + gainCapped(state, 'attachment', 0.08))
  }
  couple(d)
  if (Array.isArray(state.changes) && kinds.length) {
    const why = kinds.map((k) => KIND_CN[k] || k).join('+')
    const diff = Object.keys(d)
      .filter((k) => Math.abs(d[k] - (beforeDims[k] || 0)) >= 0.3)
      .map((k) => (DIM_CN[k] || k) + (d[k] > beforeDims[k] ? '+' : '') + (d[k] - beforeDims[k]).toFixed(1))
      .join(' ')
    if (diff) {
      state.changes.unshift({ at: nowTs(), why: why, detail: diff })
      state.changes = state.changes.slice(0, 8)
    }
  }
  return d
}

// 当前心情的一句话（给她当底色用）
export function moodLine(dims) {
  const bits = []
  const tired = dims.fatigue >= 65
  const low = dims.joy <= 35
  const high = dims.joy >= 65
  if (tired) bits.push('有点累')
  if (tired && low) bits.push('提不起劲')
  else if (high) bits.push('心里挺高兴')
  else if (low) bits.push('有点闷')
  else if (!tired) bits.push('精神不错')
  if (dims.attachment >= 65) bits.push('很想黏着妈妈')
  else if (dims.attachment <= 32) bits.push('有点疏远')
  if (dims.stress >= 55) bits.push('有点忐忑')
  if (dims.intimacy >= 70) bits.push('和她很亲近')
  if (!bits.length) bits.push('心情平常')
  return bits.join('，')
}

export function snapshot(dims) {
  return Object.fromEntries(Object.entries(dims).map(([k, v]) => [k, Math.round(v * 10) / 10]))
}