// 鱼的心 · 仪表盘：雷达 + 此刻 + 念头 + 最近变化
const { useState } = React

const ORDER = ['attachment', 'intimacy', 'curiosity', 'reflection', 'duty', 'social', 'fatigue', 'stress', 'joy']

return function Panel({ toast }) {
  const [data, setData] = useState(null)
  const [busy, setBusy] = useState(false)

  const load = async () => {
    try { setData(await call('/state')) } catch (e) { toast('读取失败') }
  }
  React.useEffect(() => {
    load()
    const t = setInterval(load, 15000)
    return () => clearInterval(t)
  }, [])

  const run = async (path, msg) => {
    setBusy(true)
    try { await call(path, {}); toast(msg); await load() } catch (e) { toast('失败') }
    setBusy(false)
  }

  const card = (...a) => h(ui.Card, { title: a[0], desc: a[1] }, ...a.slice(2))
  const muted = (t) => h('div', { className: 'ab-muted', style: { padding: '6px 0' } }, t)

  if (!data) return card('鱼的心', '读取中…', muted('正在读她的心思…'))

  const dims = data.dims || {}
  const labels = data.labels || {}
  const full = Boolean(data.full)
  const order = full ? ORDER : ['attachment', 'intimacy', 'curiosity', 'fatigue', 'joy']

  // ---- 雷达图 ----
  const radar = () => {
    const size = 220
    const c = size / 2
    const r = 82
    const n = order.length
    const pt = (i, ratio) => {
      const ang = -Math.PI / 2 + (i * 2 * Math.PI) / n
      return [c + Math.cos(ang) * r * ratio, c + Math.sin(ang) * r * ratio]
    }
    const poly = order.map((k, i) => {
      const v = Math.max(0, Math.min(100, Number(dims[k]) || 0)) / 100
      return pt(i, v).join(',')
    }).join(' ')
    const rings = [0.25, 0.5, 0.75, 1].map((ratio, idx) => h('polygon', {
      key: 'r' + idx,
      points: order.map((k, i) => pt(i, ratio).join(',')).join(' '),
      fill: 'none',
      stroke: 'var(--ab-line)',
      'stroke-width': 1,
    }))
    const spokes = order.map((k, i) => {
      const [x, y] = pt(i, 1)
      return h('line', { key: 's' + i, x1: c, y1: c, x2: x, y2: y, stroke: 'var(--ab-line)', 'stroke-width': 1 })
    })
    const names = order.map((k, i) => {
      const [x, y] = pt(i, 1.18)
      return h('text', { key: 't' + i, x: x, y: y, 'font-size': 10, fill: 'var(--ab-dim)', 'text-anchor': 'middle', 'dominant-baseline': 'middle' }, labels[k] || k)
    })
    return h('svg', { width: size, height: size, viewBox: '0 0 ' + size + ' ' + size },
      rings, spokes,
      h('polygon', { points: poly, fill: 'rgba(56,189,248,0.28)', stroke: '#38bdf8', 'stroke-width': 2 }),
      names)
  }

  // ---- 大数字 ----
  const bigNum = (key) => {
    const v = Math.round(Number(dims[key]) || 0)
    return h('div', { key: key, style: { textAlign: 'center', minWidth: 64 } },
      h('div', { style: { fontSize: 26, fontWeight: 600, color: v >= 70 ? 'var(--ab-ok)' : (v <= 30 ? 'var(--ab-warn)' : 'var(--ab-accent)') } }, String(v)),
      h('div', { className: 'ab-small', style: { color: 'var(--ab-dim)' } }, labels[key] || key))
  }

  const rows = []
  rows.push(h(ui.Row, { label: '此刻独白' },
    h('div', { style: { fontSize: 15, lineHeight: 1.7, padding: '4px 0' } }, data.thought || '（还没有念头）')))

  rows.push(h(ui.Row, { label: '九维雷达' }, h('div', { style: { padding: '4px 0' } }, radar())))

  rows.push(h(ui.Row, { label: '此刻' },
    h('div', { style: { display: 'flex', gap: 18, padding: '6px 0' } },
      ['attachment', 'intimacy', 'stress', 'joy'].map(bigNum))))

  // 九维数值明细（雷达看形状，这里看具体数字）
  const nineKeys = ['attachment', 'intimacy', 'curiosity', 'reflection', 'duty', 'social', 'fatigue', 'stress', 'joy']
  const numCell = (k) => {
    const v = Math.round(Number(dims[k]) || 0)
    const base = { attachment: 45, intimacy: 40, curiosity: 55, reflection: 50, duty: 50, social: 45, fatigue: 20, stress: 15, joy: 50 }[k]
    const diff = v - base
    const color = v >= 70 ? 'var(--ab-ok)' : (v <= 30 ? 'var(--ab-warn)' : 'var(--ab-accent)')
    return h('div', { key: k, style: { display: 'flex', alignItems: 'baseline', gap: 6, minWidth: 108, padding: '3px 0' } },
      h('span', { style: { width: 34, color: 'var(--ab-dim)' } }, labels[k] || k),
      h('span', { style: { fontSize: 16, fontWeight: 600, color: color, minWidth: 26, textAlign: 'right' } }, String(v)),
      h('span', { className: 'ab-small', style: { color: diff >= 0 ? 'var(--ab-ok)' : 'var(--ab-warn)', opacity: 0.85 } },
        (diff === 0 ? '±0' : (diff > 0 ? '+' : '') + diff)))
  }
  rows.push(h(ui.Row, { label: '九维数值' },
    h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '0 22px', padding: '4px 0' } },
      nineKeys.map(numCell))))

  const pend = (data.pending || []).map((x, i) => h('div', { key: 'p' + i, className: 'ab-small', style: { margin: '3px 0' } },
    '· [' + (x.label || x.kind) + '] ' + x.text))
  rows.push(h(ui.Row, { label: '心头的念头 (' + (pend.length || 0) + ')' },
    h('div', null, pend.length ? pend : muted('这会儿没挂着事（刚聊完就满足了）'))))

  const chg = (data.changes || []).map((x, i) => {
    const when = new Date(x.at).toLocaleTimeString('zh-CN', { hour12: false })
    return h('div', { key: 'c' + i, className: 'ab-small', style: { margin: '3px 0' } },
      '· ' + (x.why || '') + '：' + (x.detail || '') + '　' + when)
  })
  rows.push(h(ui.Row, { label: '最近的变化' }, h('div', null, chg.length ? chg : muted('还没有变化记录'))))

  const mem = (data.memory || []).map((x, i) => h('div', { key: 'm' + i, className: 'ab-small', style: { margin: '3px 0' } }, '· ' + x.text))
  if (full) rows.push(h(ui.Row, { label: '昨天的惦记' }, h('div', null, mem.length ? mem : muted('（还没攒下；睡前结算时会把没着落的事记下来）'))))

  rows.push(h(ui.Row, { label: '操作' },
    h(ui.Btn, { small: true, kind: 'primary', disabled: busy, onClick: () => run('/spawn', '冒出一个念头') }, busy ? '想着…' : '冒个念头'),
    h(ui.Btn, { small: true, disabled: busy, onClick: () => run('/night', '已结算') }, '睡前结算'),
    h(ui.Btn, { small: true, onClick: load }, '刷新'),
    h(ui.Btn, { small: true, disabled: busy, onClick: () => run('/clear', '记录已清空') }, '清记录'),
    h(ui.Btn, { small: true, disabled: busy, onClick: () => run('/reset', '已回基线') }, '回基线')
  ))

  const list = (data.thoughts || []).map((x, i) => {
    const when = new Date(x.at).toLocaleTimeString('zh-CN', { hour12: false })
    return h('div', { key: 't' + i, className: 'ab-small', style: { margin: '3px 0' } }, '· ' + x.t + '　' + when)
  })
  rows.push(h(ui.Row, { label: '独白记录' }, h('div', null, list.length ? list : muted('还没有'))))

  return card('鱼的心', data.enabled ? ('心情：' + (data.mood || '') + '　九维' + (full ? '开' : '关') + '　念头引擎' + (data.deep ? '开' : '关')) : '已关闭', ...rows)
}