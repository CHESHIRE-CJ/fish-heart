// 鱼的心：九维心情 + 念头引擎（独白/惦记/睡前结算）
import { join } from 'node:path'
import { readFileSync, writeFileSync } from 'node:fs'
import { DIMS9, newDims, decay, sleepReset, couple, feed, moodLine, snapshot } from './heart.mjs'
import { TTL, KIND_LABEL, pickKind, newThought, livePending, settle, expire, pendingHint, speakBias, settleNight } from './thoughts.mjs'

const clamp = (v) => Math.max(0, Math.min(100, v))
const TICK_MS = 10 * 60 * 1000
const day = () => new Date().toISOString().slice(0, 10)

export default {
  id: 'fish-heart',
  name: '九维心情',
  version: '0.3.0',
  api: 1,
  description: '会变的心：九维心情 + 念头生命周期（独白 / 惦记 / 睡前结算）',
  panel: 'panel.js',
  defaults: { enabled: true, full: true, deep: false, spawnMin: 25, everyMin: 30, settleHour: 23, recentMessages: 12 },
  settings: [
    { key: 'enabled', label: '开启鱼的心', type: 'switch' },
    { key: 'full', label: '九维心情', type: 'switch', hint: '关=只用最简单的四维' },
    { key: 'deep', label: '念头引擎（独白/惦记/睡前结算）', type: 'switch', hint: '开启后她会有悬着的念头，第二天还记得' },
    { key: 'spawnMin', label: '多久冒一个念头 / 更新独白（分钟）', type: 'number' },
    { key: 'settleHour', label: '几点做睡前结算（0-23）', type: 'number' },
    { key: 'everyMin', label: '多久更新一次心里话（分钟）', type: 'number' },
  ],

  setup(api) {
    // 兼容自检：宿主（Aurabot/DSH）升级后 API 有变动时，明确报出来，而不是静默失效
    const NEED = ['route', 'rule', 'command', 'ask', 'every', 'later', 'settings', 'dataDir']
    const missing = NEED.filter((k) => typeof api[k] !== 'function')
    if (!api.log || typeof api.log.info !== 'function') missing.push('log')
    if (missing.length) {
      api.log?.warn?.(`fish-heart 不兼容当前宿主：缺少 api.${missing.join('/api.')}（模块版本 1.1，需要 Aurabot 0.9+）`)
    } else {
      api.log?.info?.('fish-heart 兼容自检通过（版本 1.1）')
    }
    const file = () => join(api.dataDir(), 'state.json')
    let st = { dims: newDims(), thought: '', thoughts: [], pending: [], memory: [], changes: [], lastSpawnAt: 0, lastAt: 0, day: '', gained: {}, settledDay: '' }
    try {
      const raw = JSON.parse(readFileSync(file(), 'utf8'))
      st = { ...st, ...raw }
      st.dims = { ...newDims(), ...(raw.dims || {}) }
      if (!Array.isArray(st.pending)) st.pending = []
      if (!Array.isArray(st.memory)) st.memory = []
      if (!st.gained) st.gained = {}
    } catch {}
    const save = () => { try { writeFileSync(file(), JSON.stringify(st)) } catch {} }
    const full = () => Boolean(api.settings().full)
    const deep = () => Boolean(api.settings().deep) && full()

    const drift = (ticks = 1) => {
      const now = Date.now()
      if (full()) {
        decay(st.dims, ticks)
        if (st.lastAt && now - st.lastAt >= 2 * 3600 * 1000) sleepReset(st.dims)
      }
      st.lastAt = now
    }

    // ---- 念头 ----
    // 模型偶尔返回空（实测约一半概率），空就换个说法再要一次
    async function askOnce(opts, tries = 3) {
      for (let i = 0; i < tries; i++) {
        const out = await api.ask({ ...opts, maxTokens: (opts.maxTokens || 300) + i * 200 })
        const t = String(out || '').trim()
        if (t) return t
        api.log.debug(`模型返回空，第 ${i + 1} 次重试`)
      }
      return ''
    }
    async function spawn(force = false) {
      if (!api.settings().enabled) return null
      if (!deep() && !force) return null
      drift(1)
      // 最近 45 分钟被喂饱过的、或还挂着的念头，不再重复冒
      const nowTs = Date.now()
      const recentKinds = (st.recent || []).filter((x) => nowTs - Number(x.at || 0) < 45 * 60000).map((x) => x.kind)
      const hanging = (st.pending || []).filter((t) => t.pending !== false && Number(t.expires || 0) > nowTs).map((t) => t.kind)
      const exclude = [...new Set([...recentKinds, ...hanging])]
      let kind = pickKind(st.dims, Math.random, exclude)
      if (exclude.includes(kind)) kind = 'talk'
      const s = api.settings()
      const recent = (api.core?.hub?.chatLogOf?.(day()) || []).slice(-8)
        .filter((l) => !String(l.chatId || '').startsWith('system:'))
        .map((l) => `${l.who === 'bot' ? '我' : l.who || '有人'}：${String(l.text || '').slice(0, 30)}`)
        .join('\n')
      const out = await askOnce({
system: '你是一个角色的内心念头生成器。用她的口吻写一句完整的心声：不超过 18 字，口语、可以碎片化，但意思必须说完，不能写到一半就断（比如只写「妈妈今天好像」是不行的）。不要解释，不要引号，不要写「我想」。对象是「妈妈」（女生），必须用「她」或「妈妈」，绝不能用「他」。',
        text: `心情：${moodLine(st.dims)}\n念头类型：${KIND_LABEL[kind] || kind}\n最近聊天：\n${recent || '（安静）'}\n\n只输出那一句。`,
        maxTokens: 200,
      })
      const text = String(out || '').replace(/他/g, '妈妈').trim().replace(/^["'「『]|["'」』]$/g, '').slice(0, 30)
      if (!text) { api.log.warn('念头生成空输出'); return null }
      // 写到一半就断的（以这些词结尾）算不合格，重写一次
      const halfRe = /(好像|感觉|因为|但是|而且|要是|如果|会不会|然后|或者|觉得|想着|想说|的|地|得|就|也|在|和|跟)$/
      if (halfRe.test(text)) {
        api.log.debug('念头断在半句，重写一次：' + text)
        try {
          const again = await askOnce({
            system: '把这句话补成完整的一句话，保持她的口吻，不超过 18 字，只输出补完后的那一句。',
            text: '原句：' + text,
            maxTokens: 300,
          })
          const t2 = String(again || '').replace(/他/g, '妈妈').trim().replace(/^["'「『]|["'」』]$/g, '').slice(0, 30)
          if (t2 && !halfRe.test(t2)) text = t2
        } catch (error) {}
      }
      const t = newThought(kind, text)
      st.pending = [...livePending(st.pending), t].slice(-8)
      st.recent = [{ kind, at: t.at }, ...(st.recent || [])].slice(0, 12)
      st.lastSpawnAt = t.at
      st.thought = text
      st.thoughts = [{ t: text, at: t.at, kind }, ...(st.thoughts || [])].slice(0, 12)
      save()
      api.log.info(`冒出念头[${KIND_LABEL[kind] || kind}]：${text}`)
      return t
    }

    // 吃消息：先看能不能喂饱念头，再喂心情
    api.on('message', async (msg) => {
      if (!api.settings().enabled) return false
      const owner = Boolean(api.isOwner?.(msg.userId))
      const group = String(msg.chatId || '').startsWith('group:')
      // 这个人聊天不计入心情（妈妈的要求）
      if (String(msg.userId) === '261563736') return false
      drift(1)
      if (full()) feed(st, { text: msg.text || '', owner, group })
      if (deep()) {
        const hit = settle(st.pending, msg.text || '', Date.now(), { owner, isPrivate: String(msg.chatId || '').startsWith('private') })
        if (hit) {
          api.log.info(`念头被喂饱[${KIND_LABEL[hit.kind] || hit.kind}]：${hit.text}`)
          st.recent = [{ kind: hit.kind, at: Date.now() }, ...(st.recent || [])].slice(0, 12)
          st.dims.joy = clamp(st.dims.joy + 2)
          st.dims.stress = clamp(st.dims.stress - 1.5)
        }
        // 妈妈回话了：昨天惦记的事就算完成，别一直挂着
        const alive = (st.memory || []).filter((x) => x && !x.done)
        if (owner && alive.length) {
          for (const x of alive) { x.done = true; x.doneAt = Date.now() }
          api.log.info(`惦记完成：${alive.map((x) => x.text).join('、')}`)
        }
      }
      save()
      return false
    })

    // 每 10 分钟：过期 + （到点）睡前结算
    api.every(TICK_MS, () => {
      drift(1)
      if (deep()) {
        // 惦记超过 24 小时也算过去了
        for (const m of (st.memory || [])) {
          if (m && !m.done && Date.now() - Number(m.from || m.at || 0) > 24 * 3600 * 1000) { m.done = true; m.doneAt = Date.now() }
        }
        expire(st.pending)
        const hour = new Date().getHours()
        const sh = Number(api.settings().settleHour) || 23
        // 结算窗口：到点之后到凌晨 5 点都算，23:47 才冒的念头凌晨还能补收
        const nightWindow = hour >= sh || hour < 5
        if (nightWindow && st.settledDay !== day() && livePending(st.pending).length) {
          const mem = settleNight(st.pending)
          if (mem.length) {
            st.memory = [...mem, ...(st.memory || []).filter((x) => x && !x.done)].slice(0, 4)
            api.log.info(`睡前结算：留下 ${mem.length} 条惦记`)
            st.settledDay = day()
          }
        }
      }
      save()
    }, 'fish-heart-tick')

    // 心里话：只更新「此刻独白」，不产生悬着的念头（和念头是两件事）
    async function whisper() {
      if (!api.settings().enabled) return null
      drift(1)
      const out = await askOnce({
        system: '用一句完整、口语化的话写出她此刻的心里话（就是她心里在嘀咕什么）：不超过 18 字，不要解释，不要引号，不要写「我想」。对象是妈妈（女生），用「她」或「妈妈」，不能用「他」。',
        text: '心情：' + moodLine(st.dims) + ' 最近说过：' + ((st.thoughts || []).slice(0, 3).map((x) => x.t).join(' / ') || '（还没说）') + ' 换一种说法，别和最近说过的重复。',
        maxTokens: 300,
      })
      api.log.debug('心里话原始输出长度 ' + String(out == null ? '' : out).length)
      let t = String(out || '').replace(/他/g, '妈妈').trim().replace(/^["'「『]|["'」』]$/g, '').slice(0, 30)
      if (!t) return null
      st.thought = t
      st.lastWhisperAt = Date.now()
      st.thoughts = [{ t, at: Date.now() }, ...(st.thoughts || [])].slice(0, 12)
      save()
      api.log.info('心里话：' + t)
      return t
    }
    // 念头：每次循环重新读设置，面板上改了立刻对下一轮生效
    const scheduleSpawn = () => {
      const ms = Math.max(5, Number(api.settings().spawnMin) || 25) * 60000
      api.later(ms, async () => {
        try { await spawn() } catch (e) { api.log.warn('念头失败：' + e.message) }
        scheduleSpawn()
      })
    }
    // 重启后按上次到现在的间隔补一次，不会因为重启白等一轮
    const spawnMs0 = Math.max(5, Number(api.settings().spawnMin) || 25) * 60000
    const sinceLast = Date.now() - Number(st.lastSpawnAt || 0)
    const nextIn = st.lastSpawnAt ? Math.max(30_000, spawnMs0 - sinceLast) : 60_000
    api.later(nextIn, async () => {
      try { await spawn() } catch (e) { api.log.warn('念头失败：' + e.message) }
      scheduleSpawn()
    })

    // 心里话：同样每轮重读设置（和念头互不影响）
    const scheduleWhisper = () => {
      const ms = Math.max(5, Number(api.settings().everyMin) || 30) * 60000
      api.later(ms, async () => {
        try { await whisper() } catch (e) { api.log.warn('心里话失败：' + e.message) }
        scheduleWhisper()
      })
    }
    const whisperMs0 = Math.max(5, Number(api.settings().everyMin) || 30) * 60000
    const sinceWhisper = Date.now() - Number(st.lastWhisperAt || 0)
    const whisperIn = st.lastWhisperAt ? Math.max(20_000, whisperMs0 - sinceWhisper) : 45_000
    api.later(whisperIn, async () => {
      try { await whisper() } catch (e) { api.log.warn('心里话失败：' + e.message) }
      scheduleWhisper()
    })
    // 只留一个定时器：原来这里还有一个，导致念头冒得比设定频繁一倍

    // 上下文：只放一两句"底色"，绝不能盖过正在说的话
    const buildContext = () => {
      if (!api.settings().enabled) return ''
      const parts = []
      if (full()) parts.push(`（语气底色：${moodLine(st.dims)}。只影响语气，不要念出来。）`)
      if (deep()) {
        const p = pendingHint(st.pending)
        const pAgeMin = p ? (Date.now() - Number(p.at || 0)) / 60000 : 0
        if (p && pAgeMin >= 25) parts.push(`（心里还挂着：${p.text}。有空可以带一句，没空就算了。）`)
        else if ((st.memory || []).some((x) => x && !x.done)) {
          const mem = (st.memory || []).filter((x) => x && !x.done).find((x) => Date.now() - Number(x.from || 0) > 6 * 3600 * 1000)
          if (mem) parts.push(`（昨晚惦记过：${mem.text}。适合就提一句。）`)
        }
      }
      return parts.join('\n')
    }
    api.context(() => buildContext())

    api.rule(() => {
      if (!api.settings().enabled) return ''
      if (!deep()) return '你心里会时不时冒出一句念头。它可以影响语气，但不要原样念出来。'
      return '你有念头和心情，但它们只是底色：妈妈问什么，先老实回答什么；心里话不能当回答，也不能原样念出来。除非妈妈问你在想什么，否则不要主动汇报心情。'
    })

    // 调试：把当前会注入她上下文的话打印出来（验证用）
    api.route('/context', async () => ({ ok: true, context: buildContext() }))
    // ---- 接口 ----
    api.route('/state', async () => ({
      ok: true,
      full: full(), deep: deep(),
      thought: st.thought,
      dims: snapshot(st.dims),
      dims9: snapshot(st.dims),
      labels: Object.fromEntries(Object.entries(DIMS9).map(([k, v]) => [k, v.label])),
      mood: moodLine(st.dims),
      thoughts: (st.thoughts || []).slice(0, 12),
      pending: livePending(st.pending).map((t) => ({ kind: t.kind, label: KIND_LABEL[t.kind] || t.kind, text: t.text, at: t.at })),
      memory: (st.memory || []).filter((x) => x && !x.done).slice(0, 4),
      changes: (st.changes || []).slice(0, 8),
      bias: speakBias(st.pending),
      lastAt: st.lastAt,
      enabled: Boolean(api.settings().enabled),
    }))

    api.route('/whisper', async () => ({ ok: true, thought: await whisper() }))
    api.route('/spawn', async () => { const t = await spawn(true); return { ok: Boolean(t), thought: t ? t.text : '' } })
    api.route('/think', async () => { const t = await spawn(true); return { ok: Boolean(t), thought: t ? t.text : '' } })
    api.route('/night', async () => {
      const mem = settleNight(st.pending)
      st.memory = [...mem, ...(st.memory || []).filter((x) => x && !x.done)].slice(0, 4)
      save()
      return { ok: true, memory: st.memory }
    })
    // 只清念头记录，心情数值不动
    api.route('/clear', async () => {
      st.thought = ''
      st.thoughts = []
      st.pending = []
      st.memory = []
      st.recent = []
      save()
      return { ok: true }
    })
    api.route('/reset', async () => {
      st.dims = newDims()
      st.gained = {}
      st.lastAt = Date.now()
      st.thought = ''
      st.thoughts = []
      st.pending = []
      st.memory = []
      save()
      return { ok: true, dims: snapshot(st.dims) }
    })

    api.command({ name: '心想', desc: '看她此刻的念头和心情', run: async () => {
      const txt = Object.entries(st.dims).map(([k, v]) => `${DIMS9[k].label} ${Math.round(v)}`).join('，')
      const p = pendingHint(st.pending)
      return `念头：${p ? p.text : st.thought || '（还没有）'}\n心情：${txt}`
    } })

    api.log.info(`鱼的心已上线（九维=${full() ? '开' : '关'} 念头引擎=${deep() ? '开' : '关'}）`)
    return { state: () => st, spawn, moodLine: () => moodLine(st.dims) }
  },
}
